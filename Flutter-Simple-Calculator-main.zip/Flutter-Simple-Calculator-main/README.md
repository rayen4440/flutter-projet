# Flutter Simple Calculator App With GetX

## Preview
![Untitled](https://github.com/AmirBayat0/Flutter-Simple-Calculator/assets/91388754/d8cd280a-d786-495d-be19-2c3121dd4317)

## This link allows you to support me
* [SUPPORT](https://www.buymeacoffee.com/AmirBayat)

## My Socials:
* [INSTAGRAM](https://www.instagram.com/codewithflexz)
* [YOUTUBE]( https://www.youtube.com/c/ProgrammingWithFlexZ)
* [CONTACT ME](https://amirbayat.dev@gmail.com)
* [FIND MORE](https://zaap.bio/CodeWithFlexz)
