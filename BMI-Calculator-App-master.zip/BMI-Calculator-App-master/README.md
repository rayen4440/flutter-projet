# BMI CALCULATOR APP

![BMI-Calculator-App](https://socialify.git.ci/Lakhankumawat/BMI-Calculator-App/image?font=KoHo&forks=1&issues=1&language=1&logo=https%3A%2F%2Fuser-images.githubusercontent.com%2F55774240%2F122743259-77b8c780-d2a4-11eb-9f0e-c50cada02cc7.gif&owner=1&pattern=Brick%20Wall&pulls=1&stargazers=1&theme=Dark)

A new Flutter project.
# How It Will look 👇
<table>
  <tr>
      <td>
          <img width="250" alt="underweight" src="https://user-images.githubusercontent.com/55774240/122744527-af743f00-d2a5-11eb-84e7-b822a0d49278.jpg" /></td>
        <td>  <img width="250" alt="underweight" src="https://user-images.githubusercontent.com/55774240/122741522-aafa5700-d2a2-11eb-94ac-83350f8860c8.jpg" />
      </td>
    </tr>
<tr><td><img width="250" alt="normal" src="https://user-images.githubusercontent.com/55774240/122741486-a03fc200-d2a2-11eb-855f-2b955cbd6c71.jpg" />
</td>
<td><img width="250" alt="overweight" src="https://user-images.githubusercontent.com/55774240/122741533-ad5cb100-d2a2-11eb-90ea-02a3577f9829.jpg" /></td></tr></table>



<img align="center" width="500" alt="logo" src="https://user-images.githubusercontent.com/55774240/122635653-da725d80-d102-11eb-9208-4c8d8b4a1ac6.png" />






## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
