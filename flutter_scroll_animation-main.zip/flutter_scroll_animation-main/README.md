# Enable automatic scrolling of the listView when the active tab bar changes, and simultaneously keep the selected tab in sync as the user scrolls through the list in a Flutter application.
## [Tutorial Video on Youtube](https://youtu.be/gBQmI1kBHC0)
![newScroll anime](https://github.com/AmirBayat0/flutter_scroll_animation/assets/91388754/0ef4e11d-3cbd-4cbd-a206-bd346759ee2b)

## Preview
![main](https://github.com/AmirBayat0/flutter_scroll_animation/assets/91388754/4a4e97db-75b8-402d-abbf-04108179aae1)

## Shots
 <div class="row">
  <div class="column">
   <img src="https://github.com/AmirBayat0/flutter_scroll_animation/assets/91388754/d5883f76-b958-40cd-bbff-68330acd1729" height="400"/>
   <img src="https://github.com/AmirBayat0/flutter_scroll_animation/assets/91388754/e7ac09a1-9077-4593-b57e-0d3f7db6a672" height="400"/>
    <img src="https://github.com/AmirBayat0/flutter_scroll_animation/assets/91388754/15774222-d101-46cf-acc7-fedb90ef4192" height="400"/>
   </div>
  
</div>
 

 
## This link allows you to support me
* [SUPPORT](https://www.buymeacoffee.com/AmirBayat)

## My Socials:
* [INSTAGRAM](https://www.instagram.com/codewithflexz)
* [YOUTUBE]( https://www.youtube.com/c/ProgrammingWithFlexZ)
* [CONTACT ME](https://amirbayat.dev@gmail.com)
* [FIND MORE](https://zaap.bio/CodeWithFlexz)
